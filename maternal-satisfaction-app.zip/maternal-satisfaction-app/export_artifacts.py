# ---------------------------------------------------------------------------
# EXPORT CELL  -  paste/run at the END of the notebook (after the model has been
# trained and evaluated). It creates everything the Streamlit app needs inside a
# folder called `model/` and zips it as model_artifacts.zip.
# No respondent-level data is exported - only the model and aggregate counts.
# ---------------------------------------------------------------------------
import json, os, shutil, sys
import importlib.metadata as md
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

os.makedirs("model", exist_ok=True)

# 1) Model + preprocessing objects
joblib.dump(model, "model/logistic_regression_model.joblib")
joblib.dump(scaler, "model/scaler.joblib")
joblib.dump(list(X.columns), "model/feature_columns.joblib")
joblib.dump(list(categorical_features_for_encoding), "model/categorical_features_encoded.joblib")

# 2) Metadata used by the app (form options, aggregate counts, metrics, importances)
cat_cols = list(categorical_features_for_encoding)
num_cols = list(numerical_cols_for_scaling)

categorical = {c: [str(v) for v in pd.Series(df[c]).astype("category").cat.categories] for c in cat_cols}
numeric = {
    c: {"min": float(df[c].min()), "max": float(df[c].max()), "median": float(df[c].median())}
    for c in num_cols
}

counts = {}
for c in cat_cols + ["satisfaction"]:
    ct = pd.crosstab(df[c].astype(str), df["satisfaction"].astype(str))
    counts[c] = {str(k): {str(s): int(v) for s, v in row.items()} for k, row in ct.iterrows()}

n_dropped = len(columns_to_drop) if "columns_to_drop" in globals() else 0
metadata = {
    "dataset": {
        "n": int(len(df)),
        "n_variables": int(df.shape[1] + n_dropped),
        "pct_satisfied": float((df["satisfaction"].astype(str) == "satisfied").mean() * 100),
    },
    "metrics": {
        "accuracy": float(accuracy), "precision": float(precision), "recall": float(recall),
        "f1": float(f1), "auc": float(auc), "brier": float(brier),
    },
    "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    "coef_importance": [[str(k), float(v)] for k, v in sorted_feature_importance_lr.head(20).items()],
    "perm_importance": [[str(k), float(v)] for k, v in sorted_feature_importance_perm_lr.head(20).items()],
    "feature_order": [c for c in df.columns if c in categorical or c in numeric],
    "numeric": numeric,
    "categorical": categorical,
    "counts": counts,
}
with open("model/app_metadata.json", "w", encoding="utf-8") as f:
    json.dump(metadata, f, indent=2, ensure_ascii=False)

# 3) Exact library versions used for training (copy into requirements.txt)
def _v(pkg, module):
    try:
        return f"{pkg}=={md.version(pkg)}"
    except Exception:
        try:
            return f"{pkg}=={__import__(module).__version__}"
        except Exception:
            return None

pins = [_v(p, m_) for p, m_ in [("scikit-learn", "sklearn"), ("pandas", "pandas"), ("numpy", "numpy"),
                                ("joblib", "joblib"), ("matplotlib", "matplotlib"), ("seaborn", "seaborn")]]
with open("model/requirements.pinned.txt", "w") as f:
    f.write(f"# Trained with Python {sys.version.split()[0]} - choose the same minor version in Streamlit Cloud\n")
    f.write("streamlit\n")
    f.write("\n".join(p for p in pins if p) + "\n")

shutil.make_archive("model_artifacts", "zip", "model")
print(open("model/requirements.pinned.txt").read())
print("Done -> model_artifacts.zip (unzip it into the project's model/ folder)")
try:
    from google.colab import files
    files.download("model_artifacts.zip")
except Exception:
    pass
