"""Maternal satisfaction with delivery care - Bahir Dar city, NW Ethiopia.
Streamlit app (logistic-regression model). Deployed on Streamlit Community Cloud."""
import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import streamlit as st

from utils import preprocess

BASE = Path(__file__).parent
MODEL_DIR = BASE / "model"
COVER_IMAGE = BASE / "assets" / "pregnancy_mother.jpg"   # optional

st.set_page_config(layout="wide", page_title="Maternal Satisfaction", page_icon="🤰")

# Friendly labels for the survey variables (edit freely; unknown ones show their code)
LABELS = {
    "q101age": "Age (years)", "q102mstatu": "Marital status", "q103religi": "Religion",
    "q104ethini": "Ethnicity", "q105educat": "Education level", "q106occupa": "Occupation",
    "q107mincom": "Monthly income (ETB)", "q108reside": "Residence",
    "q1091distk": "Distance to facility (km)", "q110reason": "Reason for delivery place",
    "q112waitpl": "Waiting time at hospital", "q113privac": "Privacy at delivery",
    "q201parity": "Parity", "q203ancatt": "ANC attendance", "q204hivres": "HIV test result",
    "q205ga": "Gestational age (weeks)", "q206delimo": "Mode of delivery",
    "q2010bw": "Birth weight (grams)", "modeofdeliveryrecode": "Mode of delivery (recoded)",
    "waitingtimerecode": "Waiting time (recoded)", "privacyrecode": "Privacy (recoded)",
}


def label(col):
    return f"{LABELS[col]} ({col})" if col in LABELS else col


@st.cache_resource
def load_artifacts():
    return {
        "model": joblib.load(MODEL_DIR / "logistic_regression_model.joblib"),
        "scaler": joblib.load(MODEL_DIR / "scaler.joblib"),
        "features": joblib.load(MODEL_DIR / "feature_columns.joblib"),
        "cat_cols": joblib.load(MODEL_DIR / "categorical_features_encoded.joblib"),
        "meta": json.loads((MODEL_DIR / "app_metadata.json").read_text(encoding="utf-8")),
    }


try:
    art = load_artifacts()
except FileNotFoundError as e:
    st.error(f"Missing model file: {e.filename}. Put the files from model_artifacts.zip "
             "into the `model/` folder of the repository.")
    st.stop()

model, scaler, features, cat_cols, meta = (art[k] for k in ("model", "scaler", "features", "cat_cols", "meta"))

# --- Header ---------------------------------------------------------------
if COVER_IMAGE.exists():
    _, mid, _ = st.columns([1, 2, 1])
    mid.image(str(COVER_IMAGE), caption="Maternal care and support", width=450)

st.markdown("# Maternal Satisfaction with Delivery Care — Bahir Dar, Ethiopia")
st.markdown("### Exploration of delivery-care data and a logistic-regression model for predicting maternal satisfaction")

tab_overview, tab_desc, tab_perf, tab_pred = st.tabs(
    ["📊 Overview", "📈 Descriptive Charts", "🧠 Model Performance", "🔮 Predict"]
)

# --- Overview ---------------------------------------------------------------
with tab_overview:
    ds = meta["dataset"]
    c1, c2, c3 = st.columns(3)
    c1.metric("Total mothers surveyed", f"{ds['n']:,}")
    c2.metric("Total variables", ds["n_variables"])
    c3.metric("Overall delivery-care satisfaction", f"{ds['pct_satisfied']:.1f}%")
    st.markdown(
        "This app explores maternal satisfaction with vaginal and cesarean-section delivery care "
        "in Bahir Dar city health facilities, Northwest Ethiopia, and lets you try the fitted "
        "logistic-regression model.\n\n"
        "**Key variable groups:** socio-demographic factors, clinical and obstetric history, and "
        "quality / facility perceptions (privacy, waiting time, cleanliness, equipment, beds, distance).\n\n"
        "_Respondent-level data are not published in this app; charts use aggregated counts only._"
    )

# --- Descriptive charts -------------------------------------------------------
def counts_to_long(col):
    rows = [(cat, sat, n) for cat, d in meta["counts"][col].items() for sat, n in d.items()]
    return pd.DataFrame(rows, columns=["category", "satisfaction", "count"])


def bar(col, ax, palette="viridis"):
    long = counts_to_long(col)
    sns.barplot(data=long, x="category", y="count", hue="satisfaction", palette=palette, ax=ax)
    ax.set_xlabel("")
    ax.set_ylabel("Count")
    ax.tick_params(axis="x", rotation=40)
    for t in ax.get_xticklabels():
        t.set_ha("right")


with tab_desc:
    st.header("Descriptive charts")
    options = sorted(c for c in meta["counts"] if c != "satisfaction")
    default = options.index("modeofdeliveryrecode") if "modeofdeliveryrecode" in options else 0
    sel = st.selectbox("Choose a categorical variable:", options, index=default, format_func=label)

    left, right = st.columns([2, 1])
    with left:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        bar(sel, ax)
        ax.set_title(f"{label(sel)} by satisfaction")
        fig.tight_layout()
        st.pyplot(fig)
    with right:
        tbl = counts_to_long(sel).pivot(index="category", columns="satisfaction", values="count").fillna(0).astype(int)
        tbl["Total"] = tbl.sum(axis=1)
        st.dataframe(tbl)

    st.markdown("---")
    a, b = st.columns(2)
    with a:
        st.subheader("Overall satisfaction")
        sat = pd.DataFrame(
            [(k, sum(v.values())) for k, v in meta["counts"]["satisfaction"].items()], columns=["satisfaction", "count"]
        )
        fig, ax = plt.subplots(figsize=(6, 4.5))
        sns.barplot(data=sat, x="satisfaction", y="count", hue="satisfaction", palette="viridis", legend=False, ax=ax)
        ax.set_xlabel("Satisfaction level")
        ax.set_ylabel("Count")
        st.pyplot(fig)
    with b:
        if "modeofdeliveryrecode" in meta["counts"]:
            st.subheader("Satisfaction by mode of delivery")
            fig, ax = plt.subplots(figsize=(6, 4.5))
            bar("modeofdeliveryrecode", ax, "Set2")
            st.pyplot(fig)

    key = [c for c in ("accessandcleanessoftoiletrecode", "privacyrecode", "waitingtimerecode") if c in meta["counts"]]
    if key:
        st.markdown("---")
        st.subheader("Key quality determinants")
        for col, name in zip(st.columns(len(key)), key):
            with col:
                st.markdown(f"**{label(name)}**")
                fig, ax = plt.subplots(figsize=(5, 4))
                bar(name, ax, "coolwarm")
                fig.tight_layout()
                st.pyplot(fig)

# --- Model performance ----------------------------------------------------------
with tab_perf:
    st.header("Model performance (20% hold-out test set)")
    m = meta["metrics"]
    cols = st.columns(6)
    for col, (name, key_) in zip(cols, [("Accuracy", "accuracy"), ("Precision", "precision"), ("Recall", "recall"),
                                        ("F1-score", "f1"), ("AUC-ROC", "auc"), ("Brier score", "brier")]):
        val = m[key_]
        col.metric(name, f"{val:.4f}" if key_ in ("auc", "brier") else f"{val:.2%}")

    st.markdown("---")
    p1, p2 = st.columns(2)
    with p1:
        st.subheader("Confusion matrix")
        fig, ax = plt.subplots(figsize=(5, 4))
        sns.heatmap(meta["confusion_matrix"], annot=True, fmt="d", cmap="Blues", ax=ax,
                    xticklabels=["Not satisfied", "Satisfied"], yticklabels=["Not satisfied", "Satisfied"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        st.pyplot(fig)
    with p2:
        st.subheader("Top 10 features (|coefficient|)")
        imp = pd.DataFrame(meta["coef_importance"][:10], columns=["feature", "value"])
        fig, ax = plt.subplots(figsize=(6, 4.5))
        sns.barplot(data=imp, x="value", y="feature", hue="feature", palette="coolwarm", legend=False, ax=ax)
        ax.set_xlabel("Coefficient")
        ax.set_ylabel("")
        fig.tight_layout()
        st.pyplot(fig)

    st.subheader("Top 10 features (permutation importance)")
    perm = pd.DataFrame(meta["perm_importance"][:10], columns=["feature", "value"])
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sns.barplot(data=perm, x="value", y="feature", hue="feature", palette="magma", legend=False, ax=ax)
    ax.set_xlabel("Mean decrease in accuracy")
    ax.set_ylabel("")
    fig.tight_layout()
    st.pyplot(fig)

# --- Predict -----------------------------------------------------------------------
with tab_pred:
    st.header("Predict maternal satisfaction")
    st.write("Fill in the characteristics below (all model inputs are shown) and press **Predict**.")

    with st.form("predict_form"):
        values = {}
        grid = st.columns(3)
        for i, col in enumerate(meta["feature_order"]):
            with grid[i % 3]:
                if col in meta["numeric"]:
                    s = meta["numeric"][col]
                    values[col] = st.number_input(label(col), min_value=0.0, value=float(s["median"]),
                                                  help=f"Observed range: {s['min']:g} – {s['max']:g}")
                else:
                    values[col] = st.selectbox(label(col), meta["categorical"][col])
        submitted = st.form_submit_button("Predict satisfaction")

    if submitted:
        row = pd.DataFrame([values])
        X_new = preprocess(row, cat_cols, features, scaler)
        proba = float(model.predict_proba(X_new)[0, 1])
        st.subheader("Prediction result")
        if proba >= 0.5:
            st.success(f"Predicted: **Satisfied** (probability {proba:.1%})")
        else:
            st.warning(f"Predicted: **Not satisfied** (probability of satisfaction {proba:.1%})")
        st.progress(proba)

    st.caption("Research/educational tool based on a single study sample; not for clinical or policy decisions on its own.")
