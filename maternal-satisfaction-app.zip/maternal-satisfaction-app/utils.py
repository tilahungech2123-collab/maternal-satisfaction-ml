"""Helper functions for the Maternal Satisfaction app."""
import pandas as pd


def preprocess(raw_df, categorical_cols, feature_columns, scaler):
    """Turn one or more raw survey rows into the exact matrix the model was trained on.

    Important: get_dummies(drop_first=True) must NOT be used on new data. With a single
    row each column has one category, so drop_first would delete it and every dummy
    would become 0. Instead we create all dummies and re-index to the training columns
    (the baseline categories that were dropped in training are simply discarded here).
    """
    encoded = pd.get_dummies(raw_df, columns=list(categorical_cols), drop_first=False)
    aligned = encoded.reindex(columns=list(feature_columns), fill_value=0).astype(float)
    numeric_cols = [c for c in scaler.feature_names_in_ if c in aligned.columns]
    aligned[numeric_cols] = scaler.transform(aligned[numeric_cols])
    return aligned
