# Maternal Satisfaction with Delivery Care – Bahir Dar, Northwest Ethiopia

Machine-learning (logistic regression) analysis of maternal satisfaction with vaginal and
cesarean-section delivery care, deployed as a Streamlit app.

## Project structure
```
app.py                    Streamlit app (entry point for Streamlit Cloud)
utils.py                  Preprocessing used for new predictions
requirements.txt          Libraries installed by Streamlit Cloud
requirements-notebook.txt Libraries for re-running the notebook locally
export_artifacts.py       Same code as the export cell in the notebook
model/                    Trained model + metadata (created by the export cell)
notebooks/                Analysis notebook
assets/                   Optional cover image: assets/pregnancy_mother.jpg
data/                     Raw .sav survey data - NOT pushed to GitHub (git-ignored)
.streamlit/config.toml    Theme
```

## 1. Create the model files (once, in Colab)
1. Upload `notebooks/Python_Project.ipynb` to Colab and run it top to bottom.
2. The export cell downloads `model_artifacts.zip`. Unzip it **into `model/`**.
3. Open `model/requirements.pinned.txt` and copy the version lines into `requirements.txt`
   (scikit-learn, pandas, numpy, joblib, matplotlib, seaborn) so the saved model loads exactly.

## 2. Test locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 3. Push to GitHub
```bash
git init
git add .
git commit -m "Maternal satisfaction Streamlit app"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## 4. Deploy on Streamlit Community Cloud
1. Go to https://share.streamlit.io and sign in with GitHub.
2. **Create app** → pick the repository, branch `main`, main file path `app.py`.
3. **Advanced settings** → choose the same Python minor version printed in `model/requirements.pinned.txt`.
4. Click **Deploy**.

## Notes
- Do not commit the `.sav` dataset or any respondent-level data (HIV status, income, etc.). The app uses only aggregated counts.
- Never commit API tokens (e.g. ngrok); Streamlit Cloud does not need ngrok.
